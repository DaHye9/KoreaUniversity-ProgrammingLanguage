proc (f) (f f)
