let x = 1 in
  if x then (x-1) else 0
