let x = 1 in
  proc (y) (x+y)
