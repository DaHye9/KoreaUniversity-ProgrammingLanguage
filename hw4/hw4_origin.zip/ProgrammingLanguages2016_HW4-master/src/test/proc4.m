let f = proc (x) proc (y) (x+y) in
  ((f 3) 4)
