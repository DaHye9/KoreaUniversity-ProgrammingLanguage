let b = 3 in
let p = proc (x) proc (y) (set x = 4; y) in
  ((p <b>) <b>)
